# OIBSIP-TASK5
In this task I have complete the project SALES PREDICTION USING PYTHON in Data Science.
